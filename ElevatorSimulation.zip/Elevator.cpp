// Identification Comments Code Block
// Programmer: Fulati Aizihaer
// Programmer's ID: 1716403

#include "Elevator.h"
#include "Panel.h"
#include "Building.h"

#include <iostream>
#include <vector>
using namespace std;

#include <cstdlib>

//Elevator constructor
Elevator::Elevator(unsigned int capacity, int speed, int start) :speed(speed), CAPACITY(capacity), location(Building::floors[start]) {
  direction = IDLE;
  timer = 0;
  atFloorIndex = -1;

  for (unsigned int i = 0; i < Building::FLOORS; i++) {
    panel.addButton(Building::floors[i].label);
  }
}

//ostream operator
ostream& operator<<(ostream& out, const Elevator& e) {
  out << "Elevator at";
  out.width(6);
  out << e.location;
  out.width(12);
  if (e.direction == 1) {
    out << "going UP";
  }
  else if (e.direction == -1) {
    out << "going DOWN";
  }
  else {
    out << "IDLE";
  }
  out.width(3);
  out << e.riders.size() << " riders ";
  if (e.atFloorIndex >= 0) {
    out << "door is OPEN|" << e.timer;
  }

  out << " " << e.panel;

  return out;
}

//openDoorTo function
void Elevator::openDoorTo(int i) {
  panel.clear(Building::floors[i].label);
  atFloorIndex = i;
  resetTimer();
}

//board function
void Elevator::board(const Rider& r) {
  riders.push_back(r);
  panel.press(Building::floors[r.to].label);
  if (r.goingUp) {
    direction = UP;
  }
  else {
    direction = DOWN;
  }
  resetTimer();
}

//hasRiderForFloor function
bool Elevator::hasRiderForFloor() const {
  if (atFloorIndex == -1) {
    return false;
  }
  for (unsigned int i = 0; i < riders.size(); i++) {
    if (riders[i].to == atFloorIndex) {
      return true;
    }
  }
  return false;
}

//removeRider function
void Elevator::removeRider() {
  for (unsigned int i = 0; i < riders.size(); i++) {
    if (riders[i].to == atFloorIndex) {
      panel.clear(Building::floors[riders[i].to].label);
      riders.erase(riders.begin() + i);
      resetTimer();
      break;
    }
  }
}